<?php
if (!isset($_COOKIE["username"]) || !isset($_COOKIE["password"])) {
  die("<script> alert('Cookie tidak terdaftar!')</script>");
}
 ?>
