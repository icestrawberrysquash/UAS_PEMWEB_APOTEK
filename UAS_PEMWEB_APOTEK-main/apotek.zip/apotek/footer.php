<div class="container-fluid bgcolor-blue">
  <div class="container">
    <div class="row padding15">
      <div class="col-md-6">
        <ul class="nav nav-pills nav-justified nav-link-white">
          <li><a>&copy;mysite 2017</a></li>
          <li><a href="#">Privacy Policy</a></li>
          <li><a href="#">Sitemap</a></li>
        </ul>
      </div>

      <div class="col-md-6">
        <ul class="nav nav-pills nav-justified pull-right nav-link-white">
          <li><a href="http://fb.com/ramdan.riawan2" target="_blank">Facebook</a></li>
          <li><a href="http://instagram.com/ramdanriawan" target="_blank">Instagram</a></li>
          <li><a href="http://line.me/ti/p/~ramdanriawan" target="_blank">Line</a></li>
          <li><a href="https://api.whatsapp.com/send?phone=628973806045&text=Hai" target="_blank">WhatsApp</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>

<!-- script footer -->
<script>
  $(document).ready(function() {
    nav_l_w = $(".nav-link-white>li>a");
    nav_l_w.css('color', 'white').hover(function(){
      $(this).css('color', '#333');
    }, function(){
      nav_l_w.css('color', "white");
    });
  });
</script>
  </body>
</html>
