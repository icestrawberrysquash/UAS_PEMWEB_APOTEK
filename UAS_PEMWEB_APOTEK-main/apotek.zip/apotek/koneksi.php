<?php

include "presets.php";

$presets = new presets("db_apotek11", "root", "");
$presets->koneksi();
 ?>
